import re
cocok = re.findall(r'te+','ghdteeeh')
cocok = re.findall(r'e+','teeheeee')

polanya=r'\d\s*\d\s*\d'
cocok=re.findall(polanya,'xx1 2   3xx')
cocok=re.findall(polanya,'xx12   3xx')
cocok=re.findall(polanya,'xx123xx')

cocok = re.findall(r'^k\w+','mejakursi')
cocok = re.findall(r'k[\w\s]+','mejakursi tamu saya')

s='Alamatku adalah dita-b@google.com mas'
cocok=re.findall(r'A[\w\s]+[\w-]+@[\w.]+',s)

s='Alamatku sri@google.com serta joko@abc.com ok bro. atau don@email.com'
pola=r'([\w\.-]+)@([\w\.-]+)'
e=re.findall(pola,s)
for tup in e:
	print (' user = ',tup[0],'\n','hostname = ',tup[1],'\n\n')

f = open('indonesia.txt', 'r', encoding='latin1')
teks=f.read()
f.close()
p=r'me\w*'
c=r'di\w+'
x=r'di[\s]+[\w]+'
strings = re.findall(p,teks)
strings1 = re.findall(c,teks)
strings2 = re.findall(x,teks)

