import heapq

class PriorityQueue(object):
    def __init__(self):
        self.qlist=[]
        self._index = 0

    def __len__(self):
        return len(self.qlist)

    def isEmpty(self):
        return len(self)==0

    def enqueue(self, item, priority):
        heapq.heappush(self.qlist, (priority, self._index, item))
        self._index += 1

    def dequeue(self):
        return heapq.heappop(self.qlist)[-1]

class _PriorityQEntry(object):
    def __init__(self, data, priority):
        self.item = data
        self.priority = priority

q = PriorityQueue()
q.enqueue('Sirsak', 1)
q.enqueue('Melon', 5)
q.enqueue('Nanas', 4)
q.enqueue('Jambu', 2)
q.enqueue('Nangka', 1)