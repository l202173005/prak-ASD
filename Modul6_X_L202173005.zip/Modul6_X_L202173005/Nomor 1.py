class Mahasiswa(object):
    def __init__(self, nama, NIM, kota, us):
        self.nama = nama
        self.NIM = NIM
        self.kotaTinggal = kota
        self.uangSaku = us

c0 = MhsTIF('hujan', 10, 'Salatiga', 250000)
c1 = MhsTIF('angin', 11, 'Solo', 260000)
c2 = MhsTIF('fatin', 12, 'Surabaya', 300000)
c3 = MhsTIF('air', 25, 'Tangerang', 250000)
c4 = MhsTIF('langit', 30, 'Bogor', 350000)
c5 = MhsTIF('guntur', 40, 'Sidoarjo', 450000)
c6 = MhsTIF('awan', 16, 'Bandung', 650000)
c7 = MhsTIF('pelangi', 26, 'Surabaya', 2750000)
c8 = MhsTIF('rain', 41, 'Cilacap', 250000)
c9 = MhsTIF('could', 3, 'Semarang', 565000)
c10 = MhsTIF('wind', 8, 'Banjarmasin', 450000)

Daftar = [a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10]

def urutkanNIM(a):
    baru = {}
    for i in range(len(a)):
        baru[a[i].nama] = a[i].NIM
    listofTuples = sorted(baru.items(), key = lambda x: x[1])
    for elem in listofTuples:
        print (elem[0], ':', elem[1])
urutkanNIM(Daftar)
